A feladatok megoldására elkészített SQL parancsokat illessze be a feladat sorszáma után!
***
14. feladat

***
16. feladat

***
17. feladat

***
18. feladat

***
19. feladat

***
20. feladat

